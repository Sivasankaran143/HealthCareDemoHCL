﻿namespace HealthCareDemoDataAccess
{
    public class Class1
    {

    }
}
