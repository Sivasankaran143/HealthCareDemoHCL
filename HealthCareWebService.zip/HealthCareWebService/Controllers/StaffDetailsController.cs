﻿using AutoMapper;
using HealthCareAttandanceDemo;
using HealthCareAttandanceDemo.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HealthCareWebService.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class StaffDetailsController : ControllerBase
    {
        private HealthCareRepository _healthCareRepository;
        private readonly IMapper _mapper;
        public StaffDetailsController(HealthCareRepository healthCareRepository, IMapper mapper)
        {
            _healthCareRepository = healthCareRepository;
            _mapper = mapper;
        }
        [HttpGet(Name = "GetAllStaffDetails")]
        public JsonResult GetAllStaffDetails()
        {
            List<Model.Staff> _staffDetails = new List<Model.Staff>();
            try
            {
                List<Model.Staff> staffList = _healthCareRepository.GetAllStaffDetails();
                if (staffList != null)
                {
                    foreach(var staffLoop in  staffList)
                    {
                        Model.Staff staff =_mapper.Map<Model.Staff>(staffLoop);
                        _staffDetails.Add(staff);
                    }
                }
            }
            catch (Exception ex) {
                _staffDetails = null;
            }
            return new JsonResult(_staffDetails);
        }
        [HttpPost(Name ="AddNewStaffDetails")]
        public JsonResult AddStaffDetails(Model.Staff _staff)
        {
            bool status = false;
            try
            {
                status = _healthCareRepository.AddStaffDetails(_mapper.Map<Staff>(_staff));
            }
            catch (Exception ex)
            {
                status = false;
            }
            return new JsonResult(status);
        }
        [HttpPut("{preferenceShifId},{staffId}")]
        public JsonResult UpdateShiftPreference(string preferenceShifId,int staffId)
        {
            bool status = false;
            try
            {
                status = _healthCareRepository.UpdateShiftPreference(preferenceShifId,staffId);
            }
            catch (Exception ex)
            {
                status = false;
            }
            return new JsonResult(status);
        }
    }
}
