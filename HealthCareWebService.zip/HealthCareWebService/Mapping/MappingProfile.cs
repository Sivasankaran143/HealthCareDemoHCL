﻿using AutoMapper;
using HealthCareAttandanceDemo.Models;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace HealthCareWebService
{
    public class MappingProfile:Profile
    {
        public MappingProfile() {
            CreateMap<Staff, Model.Staff>();
            CreateMap<ShiftPreference,Model.ShiftPreference>();
        }
    }
}
