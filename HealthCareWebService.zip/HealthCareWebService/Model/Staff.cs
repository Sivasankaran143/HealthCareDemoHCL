﻿namespace HealthCareWebService.Model
{
    public class Staff
    {
        public int StaffId { get; set; }

        public string Name { get; set; }

        public string Role { get; set; }

        public string Department { get; set; }

        public string Contact { get; set; }

        public string Email { get; set; }

        public string Status { get; set; }
    }
}
