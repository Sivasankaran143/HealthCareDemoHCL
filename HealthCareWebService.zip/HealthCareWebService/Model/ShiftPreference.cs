﻿namespace HealthCareWebService.Model
{
    public class ShiftPreference
    {
        public string PreferenceId { get; set; }

        public int StaffId { get; set; }

        public string Reason { get; set; }

        public DateOnly DateRequested { get; set; }

    }
}
